import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const apiUrl = 'http://localhost:3000';

// Login Component
const Login = () => {
  const [formData, setFormData] = useState({ username: '', password: '' }); 
  const navigate = useNavigate();
  
  const handleChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(`${apiUrl}/login`, formData);
      localStorage.setItem('token', response.data.token);
      alert('Login successful');
      navigate('/'); // Redirect to workouts
    } catch (error) {
      alert('Login failed: ' + error.response.data);
    }
  };

  return (
    <div className="login-container">
      <h2 style={{ textAlign: 'center' }}>Login</h2>
      <form onSubmit={handleSubmit} className="login-form">
        <div className="login-form-row">
          <input
            name="username"
            placeholder="Username"
            value={formData.username}
            onChange={handleChange}
            required
            className="login-input"
          />
          <input
            name="password"
            placeholder="Password"
            type="password"
            value={formData.password}
            onChange={handleChange}
            required
            className="login-input"
          />
          <button type="submit" className="login-submit-button">
            Login
          </button>
        </div>
      </form>
    </div>
  );
}

export default Login;