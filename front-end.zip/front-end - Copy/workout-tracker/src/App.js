import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BrowserRouter as Router, Routes, Route, Link, useNavigate } from 'react-router-dom';
import { Activity, BarChart2, User, Clock, LogOut } from 'lucide-react';
import Login from './pages/login';
import Register from './pages/register';
import Profile from './pages/profile';
import LogWorkout from './pages/log_workout';
import Dashboard from './pages/dashboard';

import './App.css';
import './styles.css';

// Back-end address
const apiUrl = 'http://localhost:3000';


function Home() {
  const token = localStorage.getItem('token'); // Check if the user is logged in

  return (
    <div className="home-container">
      <h2>Welcome to the Workout Tracker App!</h2>
      {!token && (
        <p>
          Please <Link to="/login">login</Link> or <Link to="/register">register</Link> to start tracking your workouts!
        </p>
      )}
    </div>
  );
}

function App() {
  const [token, setToken] = useState(localStorage.getItem('token') || '');

  return (
    <Router>
      <div className="app-layout">
        <aside className="sidebar">
          <ul>
            <li><Link to="/">Home</Link></li>
            {token ? (
              <>
                <li><Link to="/workouts">Workouts</Link></li>
                <li><Link to="/profile">Profile</Link></li>
                <li>
                  <button
                    className="logout-button"
                    onClick={() => {
                      setToken('');
                      localStorage.removeItem('token');
                    }}
                  >
                    Logout
                  </button>
                </li>
              </>
            ) : (
              <>
                <li><Link to="/login">Login</Link></li>
                <li><Link to="/register">Register</Link></li>
              </>
            )}
          </ul>
        </aside>

        <main className="main-content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/register" element={<Register />} />
            <Route path="/login" element={<Login setToken={setToken} />} />
            {token && <Route path="/workouts" element={<LogWorkout token={token} />} />}
            {token && <Route path="/profile" element={<Profile token={token} />} />}
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;

