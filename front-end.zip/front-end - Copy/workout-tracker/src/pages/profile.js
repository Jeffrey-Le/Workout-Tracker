import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const apiUrl = 'http://localhost:3000';

// Profile Component
function Profile({ token }) {
  const [profile, setProfile] = useState({});
  const [formData, setFormData] = useState({});
  const [editMode, setEditMode] = useState(false);

  const fetchProfile = async () => {
    try {
      const response = await axios.get(`${apiUrl}/profile`, {
        headers: { Authorization: token },
      });
      setProfile(response.data);
    } catch (error) {
      alert('Failed to fetch profile: ' + error.response.data);
    }
  };

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`${apiUrl}/profile`, formData, {
        headers: { Authorization: token },
      });
      alert('Profile updated successfully');
      setEditMode(false);
      fetchProfile();
    } catch (error) {
      alert('Failed to update profile: ' + error.response.data);
    }
  };

  useEffect(() => {
    if (token) fetchProfile();
  }, [token]);

  return (
    <div className="profile-container">
      <h2>Profile</h2>
      {!editMode ? (
        <div>
          <table className="profile-table">
            <tbody>
              <tr>
                <td><strong>Username:</strong></td>
                <td>{profile.username}</td>
              </tr>
              <tr>
                <td><strong>Email:</strong></td>
                <td>{profile.email}</td>
              </tr>
              <tr>
                <td><strong>Age:</strong></td>
                <td>{profile.age}</td>
              </tr>
              <tr>
                <td><strong>Gender:</strong></td>
                <td>{profile.gender}</td>
              </tr>
              <tr>
                <td><strong>Height:</strong></td>
                <td>{profile.height} cm</td>
              </tr>
            </tbody>
          </table>
          <button className="edit-button" onClick={() => setEditMode(true)}>Edit Profile</button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="form-container">
          <div className="form-row">
            <div className="form-column">
              <label className="label">Username</label>
              <input
                name="username"
                placeholder="Username"
                value={formData.username}
                onChange={handleChange}
                required
                className="input"
              />
            </div>
            <div className="form-column">
              <label className="label">Email</label>
              <input
                name="email"
                placeholder="Email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="input"
              />
            </div>
          </div>
          <div className="form-row">
            <div className="form-column">
              <label className="label">Age</label>
              <input
                name="age"
                placeholder="Age"
                type="number"
                value={formData.age}
                onChange={handleChange}
                className="input"
              />
            </div>
            <div className="form-column">
              <label className="label">Gender</label>
              <input
                name="gender"
                placeholder="Gender"
                value={formData.gender}
                onChange={handleChange}
                className="input"
              />
            </div>
            <div className="form-column">
              <label className="label">Height (in cm)</label>
              <input
                name="height"
                placeholder="Height (in cm)"
                type="number"
                value={formData.height}
                onChange={handleChange}
                className="input"
              />
            </div>
          </div>
          <div className="buttons-row">
            <button type="button" className="cancel-button" onClick={() => setEditMode(false)}>
              Cancel
            </button>
            <button type="submit" className="submit-btn">
              Save
            </button>
          </div>
        </form>
      )}
    </div>
  );
}

export default Profile;