import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const apiUrl = 'http://localhost:3000';

function LogWorkout({ token }) {
  const [formData, setFormData] = useState({
    workoutType: '',
    duration: '',
    distance: '',
    calories: '',
    notes: '',
  });
  const [workouts, setWorkouts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [view, setView] = useState('history'); // 'history' or 'log' to toggle views
  const navigate = useNavigate();

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await axios.post(`${apiUrl}/workouts`, formData, {
        headers: { Authorization: token },
      });
      alert('Workout logged successfully');
      fetchWorkouts(); // Refresh the history
      setFormData({
        workoutType: '',
        duration: '',
        distance: '',
        calories: '',
        notes: '',
      });
      setView('history'); // Switch back to history view
    } catch (error) {
      alert('Failed to log workout: ' + error.response.data);
    } finally {
      setLoading(false);
    }
  };

  const fetchWorkouts = async () => {
    try {
      const response = await axios.get(`${apiUrl}/workouts`, {
        headers: { Authorization: token },
      });
      setWorkouts(response.data);
    } catch (error) {
      alert('Failed to fetch workouts: ' + error.response.data);
    }
  };

  useEffect(() => {
    if (token) fetchWorkouts();
  }, [token]);

  return (
    <div className="workout-page">
      {view === 'history' ? (
        <>
          {/* Workout History Section */}
          <div className="workout-history">
            <h3>Your Workouts</h3>
            <div className="workouts-scroll-container">
              <ul className="workouts-list">
                {workouts.map((workout) => (
                  <li key={workout.workout_id} className="workout-item">
                    <span>{workout.workout_type} - {workout.duration} mins</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Buttons to Switch Views */}
          <div className="buttons-row">
            <button className="create-button" onClick={() => setView('log')}>
              New Entry
            </button>
          </div>
        </>
      ) : (
        <>
          {/* Log Workout Form */}
          <div className="form-container">
            <form onSubmit={handleSubmit}>
              {/* First Row */}
              <div className="form-row">
                <div className="form-column">
                  <label className="label">Workout</label>
                  <select
                    name="workoutType"
                    value={formData.workoutType}
                    onChange={handleChange}
                    className="input"
                  >
                    <option value="">Select Type</option>
                    <option value="Run">Run</option>
                    <option value="Cycling">Cycling</option>
                    <option value="Swimming">Swimming</option>
                    <option value="Yoga">Yoga</option>
                  </select>
                </div>
                <div className="form-column">
                  <label className="label">Time (minutes)</label>
                  <input
                    type="number"
                    name="duration"
                    value={formData.duration}
                    onChange={handleChange}
                    className="input"
                  />
                </div>
                <div className="form-column">
                  <label className="label">Distance (km)</label>
                  <input
                    type="number"
                    name="distance"
                    value={formData.distance}
                    onChange={handleChange}
                    className="input"
                  />
                </div>
                <div className="form-column">
                  <label className="label">Calories Burned</label>
                  <input
                    type="number"
                    name="calories"
                    value={formData.calories}
                    onChange={handleChange}
                    className="input"
                  />
                </div>
              </div>

              {/* Description Row */}
              <div className="form-row">
                <div className="form-column full-width">
                  <label className="label">Description</label>
                  <textarea
                    name="notes"
                    value={formData.notes}
                    onChange={handleChange}
                    className="input description-field"
                  />
                </div>
              </div>

              {/* Buttons */}
              <div className="form-row buttons-row">
                <button type="button" className="cancel-button" onClick={() => setView('history')}>
                  Cancel
                </button>
                <button type="submit" className="submit-btn" disabled={loading}>
                  {loading ? 'Logging...' : 'Submit'}
                </button>
              </div>
            </form>
          </div>
        </>
      )}
    </div>
  );
}

export default LogWorkout;
